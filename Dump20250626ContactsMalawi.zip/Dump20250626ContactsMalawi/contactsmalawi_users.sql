-- MySQL dump 10.13  Distrib 8.0.39, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: contactsmalawi
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `township` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `region_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_district_id_foreign` (`district_id`),
  KEY `users_category_id_foreign` (`category_id`),
  KEY `users_region_id_foreign` (`region_id`),
  CONSTRAINT `users_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_region_id_foreign` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'John Banda','Area 47','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704030',4,1,2,NULL,NULL),(2,'Mary Chirwa','Blantyre City','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq','mary_picture.jpg','0881704031',1,2,1,NULL,NULL),(3,'Peter Kamanga','Mzuzu City','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704032',21,1,3,NULL,NULL),(4,'Esther Moyo','Area 25','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704033',5,2,2,NULL,NULL),(5,'James Phiri','Zomba City','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq','james_picture.jpg','0881704034',2,1,1,NULL,NULL),(6,'Grace Nkhoma','Mulanje Boma','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704035',3,1,1,NULL,NULL),(7,'Isaac Mkandawire','Ntcheu Boma','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704036',6,2,2,NULL,NULL),(8,'Charity Mhango','Karonga Town','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq','charity_picture.jpg','0881704037',22,2,3,NULL,NULL),(9,'Brian Jere','Kasungu Town','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704038',7,1,2,NULL,NULL),(10,'Patricia Gondwe','Rumphi Town','$2y$10$7bUh5MdpRaDCcyJUz4sv0OABfpb8tcAflFGGlcsBoK0HboMbn93pq',NULL,'0881704039',23,1,3,NULL,NULL),(11,'bwaila hospital','bwaila','$2y$12$tfkoI3GCHp6g/yQp4l.cDeCRY93cgnKkJduVTjDB2vySsO12PR..2',NULL,'0881704041',2,2,1,'2024-10-06 07:44:02','2024-10-06 07:44:02'),(15,'Lawrence Reneck','kabwabwa','$2y$12$YennM1IsNSpbY6oqvg/1uOU1eUlJytbyHABQSph0XOlpbpm2lHPfq','1728249951.png','0881704050',2,2,1,'2024-10-06 19:25:51','2024-10-06 19:25:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-26 21:57:10
